/**********************************************
 *
 * 		Author	:		Shawn Guo
 * 		Date	:		2013/5/4
 *      Last    :       2013/5/4
 * 		Notes	:       PWM鏂规尝杈撳嚭
 * 		Tool    :	    MSP430G2553
 *
 *      P1.2 ---> TA0.1
 *      Timer_A (DCO CLK)
 *
 *      P1.0 KEY_A 鎺у埗棰戠巼锛