/**********************************************
 *
 * 		Author	:		Shawn Guo
 *      Mail    :       iguoxiaopeng@gmail.com
 * 		Date	:		2013/4/21
 *      Last    :       2013/5/24
 * 		Notes	:       DDS
 * 		Tool    :	    MSP430G2553
 *
 *
 *      DDS+绠